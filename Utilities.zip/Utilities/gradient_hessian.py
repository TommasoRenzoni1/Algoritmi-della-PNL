from colorama import Fore, Style
import sympy as sp

def get_function():
    try:
        print(Fore.CYAN + "Enter a function of two variables x1 and x2 (e.g. x1**2 + 3*x2**2 - 7*x1*x2):" + Style.RESET_ALL)
        user_input = input()
        f = sp.sympify(user_input)
        return f
    except Exception as e:
        print(Fore.RED + f"Error while inserting the function. Please try again." + Style.RESET_ALL)
        return get_function()

def compute_gradient_and_hessian(f):
    x1, x2 = sp.symbols('x1 x2')
    gradient = [sp.diff(f, var) for var in (x1, x2)]
    hessian = sp.Matrix([[sp.diff(f, var1, var2) for var2 in (x1, x2)] for var1 in (x1, x2)])
    return gradient, hessian

def evaluate_at_point(gradient, hessian):
    while True:
        try:
            print(Fore.CYAN + "\nEnter a point xk to evaluate the gradient and Hessian (e.g. 3, 5/3):" + Style.RESET_ALL)
            # Accept input as a list of strings, parse into sympy Rational
            point = [sp.Rational(x.strip()) for x in input().split(',')]
            if len(point) != 2:
                raise ValueError("Invalid input. Must provide exactly two values.")
            
            x1, x2 = sp.symbols('x1 x2')
            point_values = {x1: point[0], x2: point[1]}

            # Compute gradient and Hessian at the given point
            grad_at_point = [g.subs(point_values) for g in gradient]
            hess_at_point = hessian.subs(point_values)

            # Handle very small values
            epsilon = sp.Rational(1, 10**12)
            grad_at_point = [0 if abs(g) < epsilon else g for g in grad_at_point]
            hess_at_point = hess_at_point.applyfunc(lambda h: 0 if abs(h) < epsilon else h)

            return grad_at_point, hess_at_point, point
        except ValueError as ve:
            print(Fore.RED + f"Error: {ve}. Please try again." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + f"Unexpected error: {e}. Please try again." + Style.RESET_ALL)

