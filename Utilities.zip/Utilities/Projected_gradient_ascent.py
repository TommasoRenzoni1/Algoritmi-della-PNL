import sys
sys.path.append("Utilities")

from colorama import Fore, Style, Back
import sympy as sp
from sympy import lcm, gcd
from scipy.optimize import linprog
from gradient_hessian import get_function, compute_gradient_and_hessian, evaluate_at_point

def normalize_vector(vec):
    denominators = [sp.nsimplify(val).as_numer_denom()[1] for val in vec]
    common_multiple = lcm(denominators)
    scaled_vec = vec * common_multiple
    numerators = [int(sp.nsimplify(val).as_numer_denom()[0]) for val in scaled_vec]
    common_divisor = gcd(*numerators)
    return scaled_vec / common_divisor

def projected_gradient_ascent(f, gradient_at_point, xk, A, b, tolerance=1e-6):
    A = sp.Matrix(A)         
    b = sp.Matrix(b)         
    xk = sp.Matrix(xk)       

    # Compute the residuals: Ax - b
    residuals = A * xk - b

    # Identify active constraints where |Ax - b| <= tolerance
    active_indices = [i for i, res in enumerate(residuals) if abs(float(res)) <= tolerance]

    # Extract the rows of A corresponding to active constraints
    M = A[active_indices, :]

    print(Fore.CYAN + "\nActive constraints:" + Style.RESET_ALL)
    for index in active_indices:
        constraint = " + ".join(
            [f"{A[index, j]}*x{j+1}" for j in range(A.shape[1])]
        ) + f" <= {b[index, 0]}"
        print(f"{constraint}")

    print("Active constraints matrix M =")
    sp.pprint(M)
    
    # Compute the projection matrix H
    n = A.shape[1]  # Number of variables
    I = sp.eye(n)   # Identity matrix of appropriate size
    if M.shape[0] == 0:
        # No active constraints
        H = I
    else:
        # Compute H = I - M.T * (M*M.T)^-1 * M
        MT = M.T
        MMT = M * MT
        try:
            MMT_inv = MMT.inv()
            H = I - MT * MMT_inv * M
        except ValueError:
            print("Matrix M*M.T is singular and cannot be inverted.")
            return

    print(Fore.CYAN + "\nProjection matrix H = I - M.T * (M * M.T).inv * M = " + Style.RESET_ALL)
    sp.pprint(H)

    gradient_at_point = sp.Matrix(gradient_at_point) 
    dk = H * gradient_at_point # because we're looking for the minimum
    print(Fore.CYAN + "\nDirection dk = +H∇f(xk) = " + Style.RESET_ALL)
    sp.pprint(dk)

    if dk.norm() == 0:
        print(Fore.YELLOW + "d_k is zero, terminating early." + Style.RESET_ALL)
        return

    # Solve for tk_hat
    # Linear programming: max t subject to A(xk + t*dk) <= b
    Adk = A * dk
    bxk = b - A * xk  # b - Ax_k

    # Prepare inputs for linprog
    A_ub = [[float(val)] for val in Adk]
    b_ub = [float(val) for val in bxk]

    result = linprog(c=[-1], A_ub=A_ub, b_ub=b_ub, bounds=(None, None), method='highs')  # Maximize t => minimize -t
    if not result.success:
        print(Fore.RED + "Linear programming problem could not be solved!" + Style.RESET_ALL)
        return

    tk_hat_rational = sp.Rational(result.x[0])
    tk_hat = result.x[0]
    approx_tk_hat = tk_hat_rational.evalf() 
    rounded_tk_hat = sp.nsimplify(approx_tk_hat, rational=True)

    print(Fore.CYAN + f"\nMaximum step size tk_hat = max t, subject to A(xk + t*dk) <= b " + Style.RESET_ALL)
    print(f"tk_hat = {tk_hat} = {rounded_tk_hat}")

    # Step 3: Determine the step size t ∈ [0, tk_hat]
    print()
    t = sp.symbols('t', real=True, positive=True)
    x_t = [xk[i] + t * dk[i] for i in range(len(xk))]
    x_t_subs = {sp.symbols(f'x{i+1}'): x_t[i] for i in range(len(xk))}
    g_t = f.subs(x_t_subs)
    g_t_expanded = sp.expand(g_t)
    print(f"ϕ(t) := f(xk + t·dk) = {g_t_expanded}")
    g_t_prime = sp.diff(g_t, t)
    print(f"ϕ'(t) = {g_t_prime}")
    t_critical = sp.solve(g_t_prime, t)

    # Filter valid t in the range [0, tk_hat]
    t_valid = [t_val for t_val in t_critical if t_val.is_real and 0 <= t_val <= tk_hat]
    g_values = [(t_val, g_t.subs(t, t_val)) for t_val in t_valid + [0, tk_hat]]  # Include boundaries 0 and tk_hat
    t_optimal, max_value = max(g_values, key=lambda item: item[1])
    print(f"Optimal step size tk = {t_optimal} (maximizes ϕ(t) = {max_value})")

    # Update the solution: x_new = xk + tk * dk
    x_new = [xk[i] + t_optimal * dk[i] for i in range(len(xk))]
    print(Fore.CYAN + "\nx_new = xk + tk·dk = " + Style.RESET_ALL)
    sp.pprint(x_new)

    # Evaluate f at xk and x_new
    xk_values = {sp.symbols(f'x{i+1}'): xk[i] for i in range(len(xk))}
    f_at_xk = f.subs(xk_values).evalf()
    print(f"\nf(xk) = {f_at_xk}")

    x_new_values = {sp.symbols(f'x{i+1}'): x_new[i] for i in range(len(xk))}
    f_at_x_new = f.subs(x_new_values).evalf()
    print(f"\nf(x_new) = {f_at_x_new}")

    return


def main():
    print(Fore.BLACK + Back.CYAN + "\nProjected gradient ascent:" + Style.RESET_ALL)
    
    # Debugging flag: Set to True to use predefined inputs
    DEBUG = False

    if not DEBUG:
        # Get the function to optimize
        f = get_function()

        # Compute the gradient and Hessian symbolically
        gradient, hessian = compute_gradient_and_hessian(f)
        print(Fore.CYAN + "\nf(x)=" + Style.RESET_ALL)
        sp.pprint(f)
        print(Fore.CYAN + "\n∇f(x)=" + Style.RESET_ALL)
        sp.pprint(gradient)

        # Evaluate the gradient, Hessian, and initial point numerically
        gradient_at_point, hessian_at_point, xk = evaluate_at_point(gradient, hessian)
        xk = [sp.Rational(val) for val in xk]
        gradient_at_point = [sp.nsimplify(val) for val in gradient_at_point]

        print(Fore.CYAN + "\nxk=" + Style.RESET_ALL)
        sp.pprint(xk)
        print(Fore.CYAN + "\n∇f(xk)=" + Style.RESET_ALL)
        sp.pprint(gradient_at_point)

        # Input for polyhedron Ax <= b
        print(Fore.CYAN + "\nEnter the polyhedron Ax <= b:" + Style.RESET_ALL)
        
        # Matrix A
        rows = int(input("Enter the number of constraints (rows of A): "))
        cols = len(xk)
        A = []
        for i in range(rows):
            row = input(f"Enter row {i+1} of A (space-separated): ").strip().split()
            if len(row) != cols:
                raise ValueError(f"Row {i+1} must have exactly {cols} elements (matching the dimension of xk).")
            A.append([sp.Rational(val) for val in row])

        # Vector b
        b = input("Enter the vector b (space-separated): ").strip().split()
        if len(b) != rows:
            raise ValueError("Vector b must have the same number of elements as the number of rows in A.")
        b = [sp.Rational(val) for val in b]

    else:
        # Debugging inputs
        f = 2 * sp.symbols('x1')**2 + 4 * sp.symbols('x2')**2 - 2 * sp.symbols('x1') - 9 * sp.symbols('x2')
        gradient, hessian = compute_gradient_and_hessian(f)
        print(Fore.CYAN + "\nf(x)=" + Style.RESET_ALL)
        sp.pprint(f)
        print(Fore.CYAN + "\n∇f(x)=" + Style.RESET_ALL)
        sp.pprint(gradient)

        xk = [-10 / 3, -2 / 3]
        xk = [sp.Rational(val) for val in xk]
        gradient_at_point = evaluate_at_point(gradient, hessian)[0]
        gradient_at_point = [sp.nsimplify(val) for val in gradient_at_point]

        print(Fore.CYAN + "\nxk=" + Style.RESET_ALL)
        sp.pprint(xk)
        print(Fore.CYAN + "\n∇f(xk)=" + Style.RESET_ALL)
        sp.pprint(gradient_at_point)

        A = [
            [-2, 1],
            [-1, 7],
            [4, 1],
            [-1, -9]
        ]
        b = [6, 3, 17, 22]
        A = [list(map(sp.Rational, row)) for row in A]
        b = list(map(sp.Rational, b))

    print("\n" + Fore.BLACK + Back.CYAN + "Performing one iteration of the projected gradient ascent:" + Style.RESET_ALL)

    projected_gradient_ascent(f, gradient_at_point, xk, A, b)

    
    

if __name__ == "__main__":
    main()
