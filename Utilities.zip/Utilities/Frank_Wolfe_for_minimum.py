import sys
sys.path.append("Utilities")

from colorama import Fore, Style, Back
import sympy as sp
from scipy.optimize import linprog
from gradient_hessian import get_function, compute_gradient_and_hessian, evaluate_at_point

from scipy.optimize import linprog
import sympy as sp

def frank_wolfe_minimum(f, gradient_at_point, xk, A, b):
    # Step 1: Solve the linearized problem
    print()
    print(f"Linearized problem: min ∇f(xk)·x, subject to Ax <= b")
    
    # Convert gradient to a list of Rational numbers
    gradient = [sp.Rational(val) for val in gradient_at_point]
    #print(f"Gradient (linear objective coefficients): {gradient}")
    
    # Prepare inputs for linprog
    A_ub = [[float(a) for a in row] for row in A]
    b_ub = [float(val) for val in b]
    gradient_float = [float(val) for val in gradient]

    # Solve the linear programming problem using scipy.optimize.linprog
    result = linprog(c=gradient_float, A_ub=A_ub, b_ub=b_ub, bounds=(None, None), method='highs')
    if not result.success:
        print(Fore.RED + "Linear programming problem could not be solved!" + Style.RESET_ALL)
        return None

    # Convert the result back to sympy.Rational
    yk = [sp.nsimplify(val) for val in result.x]
    print(f"Solution to linear problem (found with linprog): yk = {yk}")

    # Step 2: Compute the direction
    dk = [yk[i] - xk[i] for i in range(len(xk))]
    print(f"Direction dk = yk - xk = {dk}")

    # Step 3: Determine the step size t ∈ [0, 1]
    print()
    t = sp.symbols('t', real=True, positive=True)
    x_t = [xk[i] + t * dk[i] for i in range(len(xk))]
    x_t_subs = {sp.symbols(f'x{i+1}'): x_t[i] for i in range(len(xk))}
    g_t = f.subs(x_t_subs)
    g_t_expanded = sp.expand(g_t)
    print(f"ϕ(t) := f(xk + t·dk) = {g_t_expanded}")

    # Find t that maximizes g_t in [0, 1]
    g_t_prime = sp.diff(g_t, t)
    print(f"ϕ'(t) = {g_t_prime}")
    t_critical = sp.solve(g_t_prime, t)

    # Filter valid t in the range [0, 1]
    t_valid = [t_val for t_val in t_critical if t_val.is_real and 0 <= t_val <= 1]
    g_values = [(t_val, g_t.subs(t, t_val)) for t_val in t_valid + [0, 1]]  # Include boundaries 0 and 1
    t_optimal, min_value = min(g_values, key=lambda item: item[1])
    print(f"Optimal step size tk = {t_optimal} (minimizes ϕ(tk) = {min_value})")

    # Step 4: Update the solution
    print()
    x_new = [xk[i] + t_optimal * dk[i] for i in range(len(xk))]
    print(f"x_new = xk + tk·dk = {xk} + {t_optimal} · {dk} = {x_new}")

    # Evaluate function at the new point
    x_new_values = {sp.symbols(f'x{i+1}'): x_new[i] for i in range(len(xk))}
    f_at_xnew = f.subs(x_new_values)
    print(f"f(x_new) = f{tuple(x_new)} = {f_at_xnew}")

    return x_new



def main():
    print(Fore.BLACK + Back.CYAN + "\nFrank Wolfe method for minimum:" + Style.RESET_ALL)
    
    # Get the function to optimize
    f = get_function()

    # Compute the gradient and Hessian symbolically
    gradient, hessian = compute_gradient_and_hessian(f)
    print(Fore.CYAN + "\nf(x)=" + Style.RESET_ALL)
    sp.pprint(f)
    print(Fore.CYAN + "\n∇f(x)=" + Style.RESET_ALL)
    sp.pprint(gradient)

    # Evaluate the gradient, Hessian, and initial point numerically
    gradient_at_point, hessian_at_point, xk = evaluate_at_point(gradient, hessian)
    xk = [sp.Rational(val) for val in xk]
    gradient_at_point = [sp.nsimplify(val) for val in gradient_at_point]

    print(Fore.CYAN + "\nxk=" + Style.RESET_ALL)
    sp.pprint(xk)
    print(Fore.CYAN + "\n∇f(xk)=" + Style.RESET_ALL)
    sp.pprint(gradient_at_point)

    # Input for polyhedron Ax <= b
    print(Fore.CYAN + "\nEnter the polyhedron Ax <= b:" + Style.RESET_ALL)
    
    # Matrix A
    rows = int(input("Enter the number of constraints (rows of A): "))
    cols = len(xk)
    A = []
    for i in range(rows):
        row = input(f"Enter row {i+1} of A (space-separated): ").strip().split()
        if len(row) != cols:
            raise ValueError(f"Row {i+1} must have exactly {cols} elements (matching the dimension of xk).")
        A.append([sp.Rational(val) for val in row])

    # Vector b
    b = input("Enter the vector b (space-separated): ").strip().split()
    if len(b) != rows:
        raise ValueError("Vector b must have the same number of elements as the number of rows in A.")
    b = [sp.Rational(val) for val in b]

    # Perform one iteration of the Frank-Wolfe method
    print("\n" + Fore.BLACK + Back.CYAN + "Performing one iteration of Frank-Wolfe for minimum:" + Style.RESET_ALL)
    frank_wolfe_minimum(f, gradient_at_point, xk, A, b)

if __name__ == "__main__":
    main()
